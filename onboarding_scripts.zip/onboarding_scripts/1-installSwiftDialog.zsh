#!/bin/zsh
#set -x

############################################################################################
##
## Script to run onBoarding via Swift Dialog
## 
## VER 1.0.0
##
############################################################################################

# User Defined variables

weburl="https://github.com/bartreardon/swiftDialog/releases/download/v2.2/dialog-2.2.0-4535.pkg"
appname="onBoarding"                                                 
logandmetadir="/Library/Application Support/Microsoft/IntuneScripts/$appname"   # The location of our logs and last updated data
dialogWidth="1024"                                                               # Width of the dialog box
dialogHeight="500"                                                              # Height of the dialog box

# Generated variables
tempdir=$(mktemp -d)
log="$logandmetadir/$appname.log"                                               # The location of the script log file
metafile="$logandmetadir/$appname.meta"                                         # The location of our meta file (for updates)

#
# Start Logging
#
if [[ ! -d "$logandmetadir" ]]; then
	## Creating Metadirectory
	echo "$(date) | Creating [$logandmetadir] to store logs"
	mkdir -p "$logandmetadir"
fi

exec > >(tee -a "$log") 2>&1

#
# Launch Swift Dialog Onboarding
#

max_attempts=5  # Number of maximum attempts to attempt launching Swift Dialog

for ((attempt=1; attempt<=max_attempts; attempt++)); do

	touch /var/tmp/dialog.log
	chmod a+w /var/tmp/dialog.log

	/usr/local/bin/dialog --jsonfile "$logandmetadir/swiftdialog.json" --width $dialogWidth --height $dialogHeight

	# Check the exit status of Swift Dialog
	if [ $? -eq 0 ]; then
		echo "$(date) | Successfully launched $appname."
		# Write the flag file to indicate successful launch
		touch "$logandmetadir/onboarding.flag"
		break
	else
		echo "Attempt $attempt to launch $appname failed. Retrying..."
		# Add a sleep to wait before the next attempt (optional)
		sleep 5
	fi

done